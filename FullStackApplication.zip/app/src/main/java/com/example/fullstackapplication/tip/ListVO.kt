package com.example.fullstackapplication.tip

data class ListVO(
    val a: String
) {
}